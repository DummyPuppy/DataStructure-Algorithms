package edu.cmu.andrew.zhengzen;

import edu.colorado.nodes.ObjectNode;

public class OrderedLinkedListOfIntegers {
    SinglyLinkedList s = new SinglyLinkedList();

    public void sortedAdd(int i){
        try {
            if (s.countNodes() == 0){
                s.addAtFrontNode(i);
            }else {
                if (i >= (int) s.tail.getData()){
                    s.addAtEndNode(i);
                }else {
                    if (i <= (int) s.head.getData()) {
                        s.addAtFrontNode(i);
                    } else {
                        ObjectNode cursor = s.head;
                        ObjectNode prev = s.head;
                        while (i > (int) cursor.getData()) {
                            prev = cursor;
                            cursor = cursor.getLink();
                        }
                        prev.addNodeAfter(i);
                        prev.getLink().setLink(cursor);
                    }
                }
        }

        }catch (NullPointerException e)
        {

        }

    }
    public static OrderedLinkedListOfIntegers merge(OrderedLinkedListOfIntegers o1, OrderedLinkedListOfIntegers o2) {
        OrderedLinkedListOfIntegers merged;
        OrderedLinkedListOfIntegers small;
        if (o1.s.countNodes() >= o2.s.countNodes()){
         merged= o1;
        small = o2;}
        else{
            merged = o2;
            small = o1;}
        if (merged == null) {
            if (small != null) {
                return small;
            }
        } else {
            if (small != null) {
                if ((int) small.s.head.getData() >= (int) merged.s.tail.getData()) {
                    merged.s.addAtEndNode(small.s.head.getData());
                    return merged;
                } else if ((int) merged.s.head.getData() >= (int) small.s.tail.getData()) {
                    small.s.addAtEndNode(merged.s.head.getData());
                    return small;
                } else {
                    merged.s.reset();
                    merged.s.reset();
                    //suppose it is a general case where the integers will be plugged in one by one
                    // o2 integers will be plugged in o1 and become the new list


                    ObjectNode o2cur = small.s.head;
                    while (o2cur != null ) {
                        ObjectNode cur = merged.s.head;
                        ObjectNode prev = merged.s.head;
                        while ((int) o2cur.getData() > (int) cur.getData()) {
                            prev = cur;
                            cur = cur.getLink();
                            if (cur == null){
                                break;
                            }
                        }
                        prev.addNodeAfter(o2cur.getData());
                        o2cur = o2cur.getLink();
                    }
                    return merged;
                }

            } else {
                return o1;
            }

        }
        return merged;
    }


    @Override
    public String toString() {
        return this.s.toString();
    }

    public static void main(String[] args) {
        OrderedLinkedListOfIntegers olist1 = new OrderedLinkedListOfIntegers();
        OrderedLinkedListOfIntegers olist2 = new OrderedLinkedListOfIntegers();
        int[] intlist = new int[]{1,0,34,20,3,13,32,56,22,12,6,8,2,43,12,78,34,19,30,11};
        int[] lis2 = new int[]{30,23,15,8,9,65,43,80,67,34,12,56,4,8,7,6,7,34,10,29};
        for (int k:
             intlist) {
            olist1.sortedAdd(k);
        }
        for (int j:lis2
             ) {
            olist2.sortedAdd(j);
        }
        System.out.println("finish sorting");
        OrderedLinkedListOfIntegers merged = OrderedLinkedListOfIntegers.merge(olist1,olist2);
        System.out.println(merged);

    }
}
