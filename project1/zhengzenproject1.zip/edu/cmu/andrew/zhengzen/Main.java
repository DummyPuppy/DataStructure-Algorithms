package edu.cmu.andrew.zhengzen;

import java.math.BigInteger;
import java.math.*;
public class Main {


        public static void main(String[] args) {

            // create 3 BigInteger objects
//            BigInteger bi1, bi2, bi3;
//
//            // assign values to bi1, bi2
//            bi1 = new BigInteger(String.valueOf(Math.pow(7,5)));
//
//            System.out.println( bi1);

        }
    }
