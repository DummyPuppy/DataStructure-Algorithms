package edu.cmu.andrew.zhengzen;

import edu.colorado.nodes.ObjectNode;

public class SinglyLinkedList {
    ObjectNode head =null;
    ObjectNode temp;
    ObjectNode tail = null;
    /*
    empty constructor
     */
    public SinglyLinkedList(){
    }
    public void reset(){
        if (!temp.equals(head)){
            temp = head;
        }
    }
    public Object next(){
        temp = temp.getLink();
        return temp.getData();

    }
    public boolean hasNext(){
        if (temp.getLink()!=null){
            return true;
        }else {
            return false;
        }

    }
    public void addAtFrontNode(Object c){
        if (head == null){
            head = new ObjectNode(c,null);
            tail = head;
        }else {
            head = new ObjectNode(c,head);

        };
        temp = head;

    }
    public void addAtEndNode(Object c){
        if (tail ==null){
            tail = new ObjectNode(c,null);
            head = tail;
        }else{
            tail.setLink(new ObjectNode(c,null));
            tail = tail.getLink();
        }
    }
    public int countNodes(){

            return ObjectNode.listLength(head);

    }
    public Object getObjectAt(int i){
        ObjectNode ret = head;
        try {
            for (int j = 0; j < i; j++) {
                ret = head.getLink();
            }
        }catch (IndexOutOfBoundsException e){
            e.getMessage();
            e.getStackTrace();
        }
        return ret.getData();

    }
    public Object getLast(){
        if (tail ==null){
            return null;
        }else {
            return tail.getData();
        }

    }
    @Override
    public String toString(){
        return head.toString(head);
    }

    public static void main(String[] args) {
        SinglyLinkedList s = new SinglyLinkedList();
        s.addAtFrontNode('a');
        s.addAtFrontNode('b');
        s.addAtFrontNode('c');
        s.addAtFrontNode('d');
        System.out.println(s.countNodes());
        System.out.println(s.getObjectAt(2));
        System.out.println(s.getLast());
        System.out.println(s);
        s.reset();
        while (s.hasNext()){
            System.out.println(s.next());
        }




    }
}
