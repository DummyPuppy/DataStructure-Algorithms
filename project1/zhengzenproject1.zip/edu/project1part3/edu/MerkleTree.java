/**
 * Name: Chloe Zheng Zeng (zhengzen)
 * Course: 95771
 * Assignment 1
 */
package project1part3.edu;

import edu.cmu.andrew.zhengzen.SinglyLinkedList;
import edu.colorado.nodes.ObjectNode;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Scanner;

public class MerkleTree {
    SinglyLinkedList base_list  = new SinglyLinkedList();
    SinglyLinkedList last_list = new SinglyLinkedList();
    public MerkleTree(){

    }
    public String getRootHash() throws NoSuchAlgorithmException {
        if (base_list == null){
            System.out.println("Plz provide a list of data first.");
            return null;
        }else {
            last_list = createHashList(base_list);
            return (String) last_list.getObjectAt(0);
        }

    }

    private void readFile() {
        System.out.println("Please provide a file path:");
        Scanner sc = new Scanner(System.in);
        String url = sc.nextLine();
//        String[] list_of_str ;
        String line ="";
        try (BufferedReader br = new BufferedReader(new FileReader(url))) {
            while ((line = br.readLine()) !=null){
                base_list.addAtFrontNode(line);
            }
//            System.out.println(base_list.countNodes());
        }catch (Exception e){

        }
    }

    private SinglyLinkedList makeDuel(SinglyLinkedList s){
        if (s.countNodes() %2 == 1){
            s.addAtFrontNode(s.getLast());
        }
        return s;
    }
    private SinglyLinkedList createHashList(SinglyLinkedList base) throws NoSuchAlgorithmException {
        base= makeDuel(base);
        String[] nodestr = new  String[base.countNodes()];
        String[] nextlist = new String[base.countNodes()/2];
        SinglyLinkedList nextls = new SinglyLinkedList();

        for (int i = 0;i<nodestr.length;i++){
            nodestr[i] = (String) base.getObjectAt(i);
        }
        for (int j = 0; j <nextlist.length;j ++){
            nextlist[j] = h(nodestr[2*j].concat(nodestr[2*j+1]));
        }
//        System.out.println(nextlist.length);

        for (String s: nextlist){
            nextls.addAtFrontNode(s);
        }
        while (nextls.countNodes()>=2){
            nextls= createHashList(nextls);
        }

        return nextls;

    }
    public static String h(String text) throws
            NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance("SHA-256"); byte[] hash =
                digest.digest(text.getBytes(StandardCharsets.UTF_8)); StringBuffer sb = new StringBuffer();
        for (int i = 0; i <= 31; i++) {
            byte b = hash[i];
            sb.append(String.format("%02X", b));
        }
        return sb.toString();
    }

    public static void main(String[] args) throws IOException, NoSuchAlgorithmException {
        MerkleTree mtree = new MerkleTree();
        String url1= "/Users/zhengzeng/IdeaProjects/MerkleTree/src/datastr/edu/CrimeLatLonXY1990_Size2.csv";
        String url2="/Users/zhengzeng/IdeaProjects/MerkleTree/src/datastr/edu/CrimeLatLonXY1990_Size2.csv";
        String url3= "/Users/zhengzeng/IdeaProjects/MerkleTree/src/datastr/edu/CrimeLatLonXY.csv";
        String url4= "/Users/zhengzeng/IdeaProjects/MerkleTree/src/datastr/edu/smallFile.txt";
        mtree.readFile();
        System.out.println("the root hash for file" + url1+ " is \n"+ mtree.getRootHash());
        mtree.readFile();
        System.out.println("the root hash for file" + url2+ " is \n"+ mtree.getRootHash());
        mtree.readFile();
        System.out.println("the root hash for file" + url3+ " is \n"+ mtree.getRootHash());
        mtree.readFile();
        System.out.println("the root hash for file" + url4+ " is \n"+ mtree.getRootHash());
        /* So the file of CrimeLatLonXY.csv has the given root hash.
        Please provide a file path:
/Users/zhengzeng/IdeaProjects/MerkleTree/src/datastr/edu/CrimeLatLonXY1990_Size2.csv
the root hash for file/Users/zhengzeng/IdeaProjects/MerkleTree/src/datastr/edu/CrimeLatLonXY1990_Size2.csv is
8D4AFB075A6FAEA9DFF6E50F2F5E0BBE5AE90C67EBD091016B9E7FEFD76AC148
Please provide a file path:
/Users/zhengzeng/IdeaProjects/MerkleTree/src/datastr/edu/CrimeLatLonXY1990_Size2.csv
the root hash for file/Users/zhengzeng/IdeaProjects/MerkleTree/src/datastr/edu/CrimeLatLonXY1990_Size3.csv is
B58C276E2FEBCC913AFD3EB98B13C974F3761B9B5FBFB9A7DC291FF4557AF886
Please provide a file path:
/Users/zhengzeng/IdeaProjects/MerkleTree/src/datastr/edu/CrimeLatLonXY.csv
the root hash for file/Users/zhengzeng/IdeaProjects/MerkleTree/src/datastr/edu/CrimeLatLonXY.csv is
4A7AA8A16BA28250BAE897DDBE1D5EBF6B9BF7E5BEB729B01DF15F949CA56A30
Please provide a file path:
/Users/zhengzeng/IdeaProjects/MerkleTree/src/datastr/edu/smallFile.txt
the root hash for file/Users/zhengzeng/IdeaProjects/MerkleTree/src/datastr/edu/smallFile.txt is
00B5AB910801ED230477A7AA48803F513D3C8F3D0560A6E3823C86BCC4610E50
         */
    }
}
