package edu.project1part2;
import edu.cmu.andrew.zhengzen.SinglyLinkedList;


import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import java.util.Scanner;

/**
 * With reference to :https://github.com/Stephen-X/Merkle-Hellman-Knapsack-Cryptosystem/blob/master/MHK_Crypto_w_Arrays.java
 */
public class MHCyptoSystem {
    protected SinglyLinkedList w = new SinglyLinkedList();
    protected SinglyLinkedList b = new SinglyLinkedList();
    private static final int MaxChar = 80;
    private static final int bytes = MaxChar*8;
    private BigInteger q = BigInteger.TEN;
    private BigInteger r;
    public SinglyLinkedList getB() {
        return b;
    }

    public SinglyLinkedList getW() {
        return w;
    }

    public void setB(SinglyLinkedList b) {
        this.b = b;
    }

    public void setW(SinglyLinkedList w) {
        this.w = w;
    }
/*
The constructor
 */
    public MHCyptoSystem(){
        genKey();

    }
    public void run(){

        System.out.println("Please enter a string and I will encrypt it as single large integer.");
        Scanner s = new Scanner(System.in);
        String line = s.nextLine();
        String encryption = encryptChar(line);
        String decryption = decryptChar(encryption);
        System.out.printf("\n The decryption of ", line,"is %s", decryption);
    }
    private void genKey(){
        BigInteger bi = BigInteger.valueOf(3);
        for (int i = 0;i<bytes;i++){
            //building the super increasing list
            bi = bi.multiply(BigInteger.valueOf(7));
            w.addAtFrontNode(bi);
            q = q.add(bi);
        }
//        System.out.println(w.getObjectAt(0).toString());
        r = q.subtract(BigInteger.ONE);
//        System.out.println(w.countNodes());
        for (int k = w.countNodes()-1;k>=0;k--){
            b.addAtFrontNode( new BigInteger(String.valueOf(w.getObjectAt(k))).multiply(r).mod(q));
        }
    }

    private String encryptChar(String s) {
        //the encryption result variable
        System.out.println("Number of clear text byte: " +s.length());
        BigInteger result = BigInteger.valueOf(0);
        //check the length of the sentence
        if (s.length() <= 0) {
            System.out.println("You entered no char, plz enter again.");
            return null;
        } else if (s.length() > MaxChar) {
            System.out.println("It has exceeded the allowed character length. Plz enter again.");
            return null;
        } else {
            //get the character array in byte form
            String byteString = new BigInteger(s.getBytes(StandardCharsets.UTF_8)).toString(2);
            //calculate the total value of the string using b
            for (int j = 0; j < byteString.length()-1; j++) {
                BigInteger subs = new BigInteger(byteString.substring(j, j + 1));
                BigInteger n = (BigInteger) (b.getObjectAt(j));
                result = result.add(n.multiply(subs));
            }
            System.out.println(s +" is encrypted as "+ result);
            return result.toString();
        }
    }
        public String decryptChar(String ciphertext) {
        //obtain c prime values
            BigInteger c_prime = (new BigInteger(ciphertext).multiply(r.modInverse(q))).mod(q);
            //a container for decrypted binary results
            StringBuilder sb = new StringBuilder();  // the decrypted message in binary
            for (int i = 0; i < w.countNodes(); i++) {
                if (((BigInteger) w.getObjectAt(i)).compareTo(c_prime) <= 0) {  // if w > c prime , if c prime is bigger
                    c_prime = c_prime.subtract(((BigInteger) w.getObjectAt(i)));
                    sb.append(1);
                } else {
                    sb.append(0);
                    continue;
                }
            }
            String s= sb.toString();
//            System.out.println(s+" " +s.length());
            String output = "";
            for (int i =0;i<s.length()-8; i+=8){
                int charCode = Integer.parseInt(s.substring(i, i+8), 2);
//                System.out.println(charCode);
                output += (char)charCode;
            }
            System.out.println("Result of decryption "+ output);
            return output;
        }

    public static void main(String[] args) {
        MHCyptoSystem system = new MHCyptoSystem();
        system.run();
    }

}
