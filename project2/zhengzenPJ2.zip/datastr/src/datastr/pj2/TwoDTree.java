/**
 * author: Zheng Zeng
 * Andrew ID: zhengzen
 * 95771 Project 2
 * TwoDTree: the tree class with the designated methods.
 */
package datastr.pj2;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
public class TwoDTree {

    TreeNode node; //the first node
    double size =0; // the size of the tree(number of nodes)


    /**
     *
     pre-condition: The String crimeDataLocation contains the path to a file formatted in the exact same way as CrimeLatLonXY.csv
     post-condition: The 2d tree is constructed and may be printed or queried.
     * @param crimeDataLocation
     * @throws IOException
     */
    public TwoDTree(String crimeDataLocation) throws IOException {
        String line ;
        try (BufferedReader br = new BufferedReader(new FileReader(crimeDataLocation))) {
            line =br.readLine(); //to get rid of the header
            while ((line = br.readLine()) !=null) {
                size++;
//                System.out.println(line);
                if (node == null) {//create a new tree node
                    node = new TreeNode(line);
                } else {//compare the new node with the root node and go down the tree
                    node.addOnHorizontal(new TreeNode(line));
                }
            }
            }
        }

    /**
     *pre-condition: The 2d tree has been constructed.
     *post-condition: The 2d tree is displayed with an pre-order traversal.
     * Big theta(N)
     * @param nd
     */


    public void preOrderPrint(TreeNode nd){
        System.out.println(nd);
        if (nd.left !=null){
            preOrderPrint(nd.left);
        }
        if (nd.right != null) {
            preOrderPrint(nd.right);
        }

    }

    /**
     * pre-condition: The 2d tree has been constructed.
     * post-condition: The 2d tree is displayed with an in-order traversal.
     * Runtime Analysis: big theta(N)
     */
    public void inOrderPrint(TreeNode n){
        if (n.left !=null){
            inOrderPrint(n.left);
        }
        System.out.println(n);
        if (n.right!=null){
            inOrderPrint(n.right);
        }
    }

    /**
     * pre-condition: The 2d tree has been constructed.
     * post-condition: The 2d tree is displayed with an post-order traversal.
     * @param n
     */
    public void postOrderPrint(TreeNode n){
        if (n.left !=null){
            postOrderPrint(n.left);
        }
        if (n.right !=null){
            postOrderPrint(n.right);
        }
        System.out.println(n);

    }
    /**
     * pre-condition: The 2d tree has been constructed.
     * post-condition: The 2d tree is displayed with an level-order traversal.
     */
    /**
     *
     * use a queue to conduct level order print
     * first point at the root and enqueque its left and right. print out the current cursor, and pick the first one
     * on the queue for the next round of enqueuing its left and right.
     * Runtime analysis: big theta(2N-1) = big theta(n)
     * @param n
     */
    public void levelOrderPrint(TreeNode n){
        //create a queue and a cursor
        Queue queue = new Queue();
        TreeNode curs = n;
        //push the root's left and right into the queue
        queue.enqueue(curs);
        //pop the first in the queue
        while (!queue.isEmpty()){
            curs = queue.dequeue();
            //print the current node
            System.out.println(curs);
            //pop the next node
            queue.enqueue(curs.left);
            queue.enqueue(curs.right);
            //push the next node's left and right into the queue
        }

    }
    /**
     * pre-condition: The 2d tree has been constructed.
     * post-condition: The 2d tree is displayed with an reverse level-order traversal.
     */
    /**
     * It is a big theta(N)+R
     * @param n
     */
    public void reverseLevelOrderPrint(TreeNode n){
        //Create a queue with a stack inside
        Queue queue = new Queue();
        //set a cursor
        TreeNode curs = n;
        //enqueue the queue first
        queue.enqueue(curs);
        while (!queue.isEmpty()) {
            //get the first in line
            curs = queue.dequeue();
            //push the node's left and right into the queue
            //at the same time the popped one is pushed into the stack
            queue.enqueue(curs.left);
            queue.enqueue(curs.right);

        }
        //obtain the stack where the first element is the last element from the queue
        Stack stack = queue.st;
        //pop out the first element in the stack
        while (!stack.isEmpty()){
            System.out.println(stack.pop());
            //continue on the stack
        }
    }

    /**
     * precondition: 1. the points are correct; 2.the tree has been established
     * post-condition: the nodes are stored in a stack and popped out into a String
     * @param x1
     * @param y1
     * @param x2
     * @param y2
     * @return
     * @throws IOException
     */
    public ListOfCrimes findPointsInRange(double x1, double y1, double x2, double y2) throws IOException {
        //create the queue for actions
        Queue queue = new Queue();
        //create the listofcrime object
        ListOfCrimes list = new ListOfCrimes();
        //initiate a cursor
        TreeNode curs = node;
        while (curs!=null){
            //add its children nodes
            queue.enqueue(curs.left);
            queue.enqueue(curs.right);
            //print the current node
//            System.out.println(curs);
            //compare the current cursor node to the given area
            boolean inside = curs.x >= x1 && curs.x <= x2 && curs.y >= y1 && curs.y <= y2;
            //if it is within the range
            if (inside){
                //push the cursor node into the stack of the list
                list.addToRange(curs);
            }
            //point to the next node
            curs = queue.dequeue();
        }
        //create the kml file
        list.toKML();
        //return the list of crime nodes
        return list;
    }

    /**
     * pre-condition: 1. the tree is established;2. there is only one nearest point
     * post-condition: the distance and nearest point can be printed out
     * @param x1
     * @param y1
     * @return
     */
    public Neighbor nearestNeighbor(double x1, double y1){
        //create a queue of level-order
        int count = 0;
        Queue queue = new Queue();
        Neighbor neighbor = new Neighbor();
        //assign a cursor
        TreeNode curs = node;
        //calculate the distance between the node and the designated point
        double dis = Math.sqrt(Math.pow(curs.x-x1,2) + Math.pow(curs.y-y1,2));
        //set the benchmark
        neighbor.setDistance(dis);
        neighbor.setNearest(curs);
        //populate the queue with the root node's left child
        queue.enqueue(curs.left);
        while (!queue.isEmpty()){
            count++;
            //compute the first one in the queue
            dis = Math.sqrt(Math.pow(curs.x-x1,2) + Math.pow(curs.y-y1,2));
            //if the distance is equal or smaller than the root
            if (dis < neighbor.distance){
                //set the cursor to be the nearest, and its distance to be the shortest.
                neighbor.setNearest(curs);
                neighbor.setDistance(dis);
                //add the cursor's left and right node
                queue.enqueue(curs.left);
//                queue.enqueue(curs.right);
            }else {
                queue.enqueue(curs.right);
            }
            //get the next node in queue
            curs = queue.dequeue();


        }
        //return the neighbor information
        System.out.println("went through nodes:" +count);
        return neighbor;
    }
////some test codes with a small dataset
//    public static void main(String[] args) throws IOException {
//        TwoDTree tree = new TwoDTree("/Users/zhengzeng/Documents/datastr/src/datastr/CrimeLatLonXY1990_Size8.csv");
////        tree.inOrderPrint(tree.node);
////        System.out.println("================");
////        tree.preOrderPrint(tree.node);
////        System.out.println("================");
////        tree.postOrderPrint(tree.node);
////        System.out.println("=================");
////        tree.levelOrderPrint(tree.node);
////        System.out.println("=================");
////        tree.reverseLevelOrderPrint(tree.node);
////        ListOfCrimes l = tree.findPointsInRange(1357605.688 411838.5393 1358805.688 413038.5393);
////        System.out.println(l);
////        Neighbor neighbor = tree.nearestNeighbor(1359951,410726);
////        System.out.println(neighbor);
//    }
}
