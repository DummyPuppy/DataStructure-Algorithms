package datastr.pj2;

class TreeNode {
    //the values of the crime record
    double x;
    double y;
    double lat;
    double lon;
    public TreeNode left = null;
    public TreeNode right = null;
    String crime;
    String streetname;
    String crimetype;
//initiate a treenode
    public TreeNode(String info) {
        String[] string = info.split(",");
        this.x = Double.parseDouble(string[0]);
        this.y = Double.parseDouble(string[1]);
        this.lat = Double.parseDouble(string[7]);
        this.lon = Double.parseDouble(string[8]);
        this.crime = info;
        this.streetname = string[3];
        this.crimetype = string[4];
    }

    //add the note based on y value
    public void addOnVertical(TreeNode tn) {
        if (tn.y < y) {
            if (this.left == null) {
                this.left = tn;
            } else {
                this.left.addOnHorizontal(tn);
            }
        } else {
            if (this.right == null) {
                this.right = tn;
            } else {
                this.right.addOnHorizontal(tn);
            }

        }
    }

    //add the note based on x value
    public void addOnHorizontal(TreeNode tn) {

        if (tn.x < x) {
            if (this.left == null) {
                this.left = tn;
            } else {//if the left node is occupied, turn to the left's children position
                this.left.addOnVertical(tn);//switch discriminating direction
            }
        } else {
            if (this.right == null) {
                this.right = tn;
            } else {
                this.right.addOnVertical(tn);//swiitch directions
            }

        }
    }

    //get the detail about the crime information

    public String getCrime() {
        return crime;
    }
    //get the street name

    public String getStreetname() {
        return streetname;
    }

    @Override
    public String toString() {
        return "TreeNode[" +
                "x=" + x +
                ", y=" + y +"] ";
    }
}