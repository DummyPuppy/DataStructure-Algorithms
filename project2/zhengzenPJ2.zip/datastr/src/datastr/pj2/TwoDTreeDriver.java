/**
 * author: zhengzen
 * Driver instruction: click on run and it will work and loop until you decide to stop
 */
package datastr.pj2;

import java.io.IOException;
import java.util.Scanner;

public class TwoDTreeDriver {
    public static void main(String[] args) throws IOException {
        //connect to the data
        TwoDTree tree = new TwoDTree("/Users/zhengzeng/Documents/datastr/src/datastr/pj2/CrimeLatLonXY.csv");
        System.out.println("Crime file loaded into 2d tree with 27218 records.\n" +
                "What would you like to do?\n" +
                "1: inorder\n" +
                "2: preorder\n" +
                "3: levelorder\n" +
                "4: postorder\n" +
                "5: reverseLevelOrder\n" +
                "6: search for points within rectangle\n" +
                "7: search for nearest neighbor\n" +
                "8: quit");
        Scanner sc = new Scanner(System.in);
        int action = sc.nextInt();
        while (action !=8){//if you decide not to quit
            switch (action){//different actions to take
                case 1: tree.inOrderPrint(tree.node);break;
                case 2: tree.preOrderPrint(tree.node);break;
                case 3: tree.levelOrderPrint(tree.node);break;
                case 4: tree.postOrderPrint(tree.node);break;
                case 5: tree.reverseLevelOrderPrint(tree.node);break;
                case 6: {//to find nodes in a string
                    System.out.println("Give me some coordinates.");
                    sc = new Scanner(System.in);
                    double x1 = sc.nextDouble();
                    double y1 = sc.nextDouble();
                    double x2 = sc.nextDouble();
                    double y2 = sc.nextDouble();
                    ListOfCrimes list = tree.findPointsInRange(x1,y1,x2,y2);
                    System.out.println(list);
                    break;
                }
                case 7:{ //faster than the given 27 nodes to go through, hit at 18 nodes
                    System.out.println("Give me a point");
                    sc = new Scanner(System.in);
                    double x1 = sc.nextDouble();
                    double y1 = sc.nextDouble();
                    Neighbor neighbor = tree.nearestNeighbor(x1,y1);
                    System.out.println(neighbor);
                    break;
                }
                default:
                    System.out.println("Please enter a valid number!");break;
            }
            //after one mission is executed, await your next instruction
            System.out.println("Give me your next instruction:");
            //read in the next action code
            sc = new Scanner(System.in);
            action = sc.nextInt();
        }
        //when you quit
        System.out.println("Thank you for exploring Pittsburgh crimes in the 1990's.");
    }
}
