/**
 * author: zhengzen
 * class: Neighbor
 * return: the nearest neighbor node to a specific point and its distance
 * method: only for set distance and set the node
 */
package datastr.pj2;

public class Neighbor {
    //the nearest neighbor tree node
    TreeNode nearest ;
    //the distance
    double distance =0;
    //constructor
    public Neighbor(){

    }
//set the distance to be the new shortest one
    public void setDistance(double distance) {
        this.distance = distance;
    }
//set the nearest node
    public void setNearest(TreeNode nearest) {
        this.nearest = nearest;
    }

    @Override
    public String toString() {
        return "Neighbor{" +
                nearest.getCrime()+"}" +"\n distance: "+ distance;
    }
}
