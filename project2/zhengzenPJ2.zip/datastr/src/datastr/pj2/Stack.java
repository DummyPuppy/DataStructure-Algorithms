/**
 * author: zhengzen
 * class: Stack
 * use the treelinkedlist to perform stack functions
 */
package datastr.pj2;

public class Stack {
    TreeLinkedList stack; //initiate a linked list
    public Stack(){
        stack = new TreeLinkedList();
    }
    //push the element to the front
    public void  push(TreeNode tn){
        stack.pushfront(tn);
    }
    //pop the element in the front
    public TreeNode pop(){
        TreeNode p = stack.popfront();

        return p;
    }
    //check if it is empty
    public boolean isEmpty(){
        return stack.isEmpty();
    }
}
