/**
 * author:zhengzen
 * class: ListOfCrimes
 * use a stack to store the points in range.
 */
package datastr.pj2;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

public class ListOfCrimes {
    public TreeLinkedList stack;
    public  ListOfCrimes(){
        stack = new TreeLinkedList();
    }

    public void addToRange(TreeNode tn){
        stack.pushfront(tn);
//        System.out.println(stack);

    }
    public void toKML() throws IOException {
        TreeLinkedList tem =stack;
        String beforepm = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n" +
                "<kml xmlns=\"http://earth.google.com/kml/2.2\"> <Document>\n" +
                "  <Style id=\"style1\">\n" +
                "    <IconStyle>\n" +
                "    <Icon>\n" +
                "    <href>http://maps.gstatic.com/intl/en_ALL/mapfiles/ms/micons/blue-dot.png</href></Icon></IconStyle>\n" +
                "  </Style>";
        String afterpm = "</Document>\n" +
                "</kml>";
        String placemark ="" ;
        while (!tem.isEmpty()){
            TreeNode k = tem.pophead();
            if (k !=null) {
                double latitude = k.lat;
                double longitude = k.lon;
                placemark += " <Placemark>\n" +
                        "    <name>"+k.getStreetname()+"</name>\n" +
                        "    <description>"+k.crimetype+"</description> <styleUrl>#style1</styleUrl>\n" +
                        "    <Point>\n" +
                        "      <coordinates>" + latitude + "," + longitude + ",0.000000</coordinates>\n" +
                        "    </Point>\n" +
                        "  </Placemark>";
            }else {
                break;
            }

        }
        try {
            String file = beforepm + placemark + afterpm;
            Writer tofile = new FileWriter("/Users/zhengzeng/Documents/datastr/src/datastr/pj2/PGHCrimes.kml");
            tofile.write(file);
            tofile.flush();
            tofile.close();
            System.out.println("file has been created!");
        }catch (Exception e){
            e.getStackTrace();
        }
    }

    @Override
    public String toString() {
        String line  = "";
        if (stack!=null){
            while (!stack.isEmpty()){
                line +=stack.pophead().toString();
            }

        }
        return line;
    }

//    public static void main(String[] args) {
//        ListOfCrimes loc = new ListOfCrimes();
//        TreeNode node1 = new TreeNode("3","2","3","4");
//        TreeNode node2 = new TreeNode("4","3","1","0.5");
//        TreeNode node3 = new TreeNode("1","9","1","7");
//        loc.addToRange(node1);
//        loc.addToRange(node2);
//        loc.addToRange(node3);
//    }
}
