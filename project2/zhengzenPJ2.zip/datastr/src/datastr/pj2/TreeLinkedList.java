/**
 * author: zhengzen
 * class: TreeLinkedList as stack or queue
 * can be used as stack or queue, depending on the methods you use.
 * based on ObjectNode class
 */
package datastr.pj2;

public class TreeLinkedList {
    //front point to the head of the list
    ObjectNode front ;
    //rear point to the tail of the list
    ObjectNode rear ;
    /*
    empty constructor
     */
    public TreeLinkedList(){
        front = null;
    }

    public boolean isEmpty(){
        if (front !=null)
            return false;
        else
            return true;
    }
    //get values from the front

    /**
     * Here two push and pop methods are for queue
     * @return
     */
    public TreeNode popfront(){
        //get the first-in element;
        ObjectNode p = front;
        //point the head pointer to the end
        ObjectNode newfront = rear;
        //traverse through the list till the pointer comes to the node before the original front node
        while (newfront.getLink()!=null) {
            if (newfront.getLink()!=p) {
                newfront = newfront.getLink();
            }else {
                break;
            }
        }
        //test if rear is the front, if it is, then it is the last node.
        if (newfront.getLink() ==null){
            front = null;
        }else {
            //there are still more than one node
            //let that node point to nothing
            newfront.setLink(null);
            front = newfront;
        }

        return (TreeNode) p.getData();
    }

    //every time it pushed new values to the tail
    public void  pushtail(TreeNode n){
        if (front ==null) {
            ObjectNode p = new ObjectNode(n, null);
            front = p;
            rear = front;
        }else {
            rear = new ObjectNode(n,rear);
        }
    }

    /**
     * These two push & pop methods are for stack purpose
     * @return
     */

    public TreeNode pophead(){
        TreeNode curs;
        if (front !=null) {
            curs = (TreeNode) front.getData();
            front = front.getLink();
            return  curs;
        }else {
            return null;
        }
    }

    public void  pushfront(TreeNode n){
        if (front ==null) {
           ObjectNode p = new ObjectNode(n, null);
           front = p;
        }else {
            front = new ObjectNode(n,front);
        }
    }

    @Override
    public String toString() {
        return "TreeLinkedList{" +
                "front=" + front +
                ", rear=" + rear +
                '}';
    }

}
