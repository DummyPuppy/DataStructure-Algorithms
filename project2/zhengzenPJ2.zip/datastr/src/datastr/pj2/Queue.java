/**
 * author: zhengzen
 * class: Queue
 * use a linked list ot perform queue functions
 */
package datastr.pj2;

public class Queue {
    TreeLinkedList queue;
    Stack st;
    //to add an object to the end of the queue (front of the linked list)
    public Queue(){
        queue = new TreeLinkedList();
        st = new Stack();
    }

//to push an element into the queue
    public void enqueue(TreeNode tn){
        if (tn !=null) {
            queue.pushtail(tn);
        }else {

        }

    }
    //to get the object from the top of the queue (front of the linked list)
    public TreeNode  dequeue(){
        if (!queue.isEmpty()){
        TreeNode n = queue.popfront();
        st.push(n);
        return n;
        }
        else
            return null;

    }
    //check if the queue is empty
    public boolean isEmpty(){
        if (queue.isEmpty()){
            return true;
        }else
            return false;
    }

}
