package edu.cmu.andrew.zhengzen;

import edu.colorado.nodes.ObjectNode;

public class TestObjectNode {

    public static void main(String[] args) {
        char[] letters = "abcdefghijklmnopqrstuvwxyz".toCharArray();
        ObjectNode head = new ObjectNode(letters[0],null);
        ObjectNode cursor = head;
        for (int i = 1;i<26;i++) {
                cursor.addNodeAfter(letters[i]);
                cursor= cursor.getLink();
            }

        System.out.println("following:");
        ObjectNode.toString(head);
        ObjectNode.displayEveryThird(head);
        System.out.println("Number of nodes = " +ObjectNode.listLength(head));
        System.out.println("Number of nodes = " + ObjectNode.listLength_rec(head));
        ObjectNode k = ObjectNode.listCopy(head);
        ObjectNode.toString(k);
        System.out.println("Number of nodes in k = " +ObjectNode.listLength(k));
        System.out.println("Number of nodes in k = " + ObjectNode.listLength_rec(k));
        ObjectNode k2 = ObjectNode.listCopy_rec(head);
        ObjectNode.toString(k2);
        System.out.println("Number of nodes in k2 = " +ObjectNode.listLength(k2));
        System.out.println("Number of nodes in k2 = " + ObjectNode.listLength_rec(k2));

        }
    }
