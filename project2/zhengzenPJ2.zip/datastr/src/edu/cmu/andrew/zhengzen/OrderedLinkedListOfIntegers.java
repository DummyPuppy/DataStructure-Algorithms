package edu.cmu.andrew.zhengzen;

import edu.colorado.nodes.ObjectNode;

import java.util.Random;
import java.util.random.RandomGenerator;

public class OrderedLinkedListOfIntegers {
    SinglyLinkedList s;

    public void sortedAdd(int i){
        if (s.head ==null){
            s.addAtFrontNode(i);
        }else {
            for (int j = 0; j < s.countNodes();j++){
                int k = (int) s.getObjectAt(j);
                if (k <= i){
                    s.temp.addNodeAfter(i);
                    break;
                }else {
                    continue;
                }
            }
        }


    }
    public static OrderedLinkedListOfIntegers merge(OrderedLinkedListOfIntegers o1, OrderedLinkedListOfIntegers o2){
        ObjectNode otemp;
        if (o1 ==null) {
            if (o2 ==null){
                return  null;
            }else {
                return o1;
            }

        }
        if ((int)o2.s.head.getData()>=(int) o1.s.tail.getData()){
            o1.s.addAtEndNode(o2.s.head);
            return o1;
        }
        else if ((int)o1.s.head.getData()>=(int) o2.s.tail.getData()) {
            o2.s.addAtEndNode(o1.s.head);
            return o2;
        }
        o1.s.reset();
        o2.s.reset();

        while (o2.s.hasNext()) {
            if ((int) o1.s.temp.getData() < (int) o2.s.temp.getData()){
            }else{
                o1.s.temp.addNodeAfter(o2.s.temp.getData());
                o2.s.temp = o2.s.temp.getLink();
            }
            o1.s.temp = o1.s.temp.getLink();

        }

        return o1;
    }

    public static void main(String[] args) {
        OrderedLinkedListOfIntegers olist1 = new OrderedLinkedListOfIntegers();
        OrderedLinkedListOfIntegers olist2 = new OrderedLinkedListOfIntegers();
        int[] intlist = new int[]{1,34,20,3,9,10,4,22,666,30,54,23,22,67,44,88,13,32,56,22,12};
        int[] lis2 = new int[]{30,23,12,4,29,7,4,78,5,4,3,7,4,3,2,7,7,53,212,43,8,5,8,9,65,43};
        for (int k:
             intlist) {
            olist1.sortedAdd(k);
        }
        for (int j:lis2
             ) {
            olist2.sortedAdd(j);
        }
        OrderedLinkedListOfIntegers merged = OrderedLinkedListOfIntegers.merge(olist1,olist2);
        System.out.println(merged);

    }
}
